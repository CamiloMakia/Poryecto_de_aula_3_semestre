create database db_sistema_ventas;

use db_sistema_ventas;



-- Crear tabla de clientes

create table tabla_clientes(
idCsuario int(11) auto_increment primary key,
nombre varchar(30) not null,
apellido varchar(30) not null,
cedula varchar(15) not null,
telefono varchar(15) not null,
estado int(1) not null
);

-- Crear tabla de categorias 

create table tabla_categorias(
idCategoria int(11) auto_increment primary key,
descripcion varchar(200) not null,
estado int(1) not null
);

-- Crear tabla de productos

create table tabla_productos(
idProducto int(11) auto_increment primary key,
nombre varchar(100) not null,
cantidad int(11) not null,
precio double(10,2) not null,
descripcion varchar(200) not null,
idCategoria int(11) not null,
estado int(1) not null
);

-- Creaar tabla de informacion de venta

create table tabla_info_ventas(
idVenta int(11) auto_increment primary key,
idCliente int(11) not null,
valorPagar double(10,2) not null,
precio double(10,2) not null,
descripcion varchar(200) not null,
fechaVenta date not null,
estado int(1) not null
);

-- Creaar tabla de detalles de venta

create table tabla_detalles_venta(
idDetallesVenta int(11) auto_increment primary key,
idVenta int(11) not null,
idProducto int(11) not null,
cantidad int(11) not null,
precioUnitario double(10,2) not null,
subtotal double(10,2) not null,
descuento double(10,2) not null,
totalPagar double(10,2) not null,
estado int(1) not null
);

-- Crear Tabla de usuarios 

create table tabla_de_usuarios(
idUsuario int(11) auto_increment primary key,
nombre varchar(30) not null,
apellido varchar(30) not null,
usuario varchar(15) not null,
password varchar(15) not null,
telefono varchar(15) not null,
estado int(1) not null
);

-- crear un usuario 
insert into tabla_de_usuarios(nombre, apellido, usuario, password, telefono, estado)
values("Juan", "Barrios", "root", "12345", "3002620034", 1);
-- crear categorias
insert into tabla_categorias(idCategoria, descripcion, estado)
values("001", "Platillo", 1);
insert into tabla_categorias(idCategoria, descripcion, estado)
values("002", "Bebida", 1);
insert into tabla_categorias(idCategoria, descripcion, estado)
values("003", "Acompañante", 1);

SELECT * FROM tabla_detalles_venta;
SELECT * FROM tabla_productos;
show tables;

SELECT * FROM tabla_de_usuarios;
