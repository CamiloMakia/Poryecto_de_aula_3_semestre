package controller;

import java.sql.SQLException;
import com.mysql.jdbc.Statement;
import java.sql.Connection;
import conexion.Conexion;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import model.Usuario;
import java.sql.ResultSet;

public class Controller_database_usuario {

    public boolean loginUsuario(Usuario objeto) {

        boolean confirmacion = false;
        Connection conexion = Conexion.conectar();
        String sql = "select usuario, password from tabla_de_usuarios where usuario = '" + objeto.getUsuario() + "' and password = '" + objeto.getPassword() + "';";
        Statement state;

        try {

            state = (Statement) conexion.createStatement();
            ResultSet result = state.executeQuery(sql);

            while (result.next()) {
                confirmacion = true;
            }

        } catch (SQLException e) {
            System.out.println("Error al iniciar sesión");
            JOptionPane.showMessageDialog(null, "Error al iniciar sesión");

        }
        return confirmacion;
    }
    
    // metodo guardar nuevo usuario
    public boolean guardar(Usuario objeto) {
        boolean respuesta = false;
        Connection conexion = Conexion.conectar();
        try {
            PreparedStatement consulta = conexion.prepareStatement("insert into tabla_de_usuarios values(?,?,?,?,?,?,?)");
            consulta.setInt(1, 0);//id
            consulta.setString(2, objeto.getNombre());
            consulta.setString(3, objeto.getApellido());
            consulta.setString(4, objeto.getUsuario());
            consulta.setString(5, objeto.getPassword());
            consulta.setString(6, objeto.getTelefono());
            consulta.setInt(7, objeto.getEstado());
            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error al guardar usuario: " + e);
        }
        return respuesta;
    }

    // metodo actualizar usuario
    public boolean actualizar(Usuario objeto, int idUsuario) {
        boolean respuesta = false;
        Connection conexion = Conexion.conectar();
        try {

            PreparedStatement consulta = conexion.prepareStatement("update tabla_de_usuarios set nombre=?, apellido = ?, usuario = ?, password= ?, telefono = ?, estado = ? where idUsuario ='" + idUsuario + "'");
            consulta.setString(1, objeto.getNombre());
            consulta.setString(2, objeto.getApellido());
            consulta.setString(3, objeto.getUsuario());
            consulta.setString(4, objeto.getPassword());
            consulta.setString(5, objeto.getTelefono());
            consulta.setInt(6, objeto.getEstado());

            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error al actualizar usuario: " + e);
        }
        return respuesta;
    }
    
    // eliminar usuario
    public boolean eliminar(int idUsuario) {
        boolean respuesta = false;
        Connection conexion = Conexion.conectar();
        try {
            PreparedStatement consulta = conexion.prepareStatement(
                    "delete from tabla_de_usuarios where idUsuario ='" + idUsuario + "'");
            consulta.executeUpdate();

            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error al eliminar usuario: " + e);
        }
        return respuesta;
    }
    
    // metodo para verificar que existe un usuario
    public boolean existeUsuario(String usuario) {
        boolean respuesta = false;
        String sql = "select usuario from tabla_de_usuario where usuarios = '" + usuario + "';";
        java.sql.Statement st;
        try {
            Connection conexion = Conexion.conectar();
            st = conexion.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                respuesta = true;
            }
        } catch (SQLException e) {
            System.out.println("Error al consultar usuario: " + e);
        }
        return respuesta;
    }
}
