package controller;

import conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import model.InformacionVenta;
import model.DetallesDeVenta;

/**
 * @author srmakia
 */
public class Controller_facturarVenta {
    
    public static int idInfoRegistrada;
    java.math.BigDecimal iDColVar;

    //metodo para guardar la informacion de venta
     
    public boolean guardar(InformacionVenta objeto) {
    boolean respuesta = false;
    Connection conexion = Conexion.conectar();
    try {
        PreparedStatement consulta = conexion.prepareStatement(
            "INSERT INTO tabla_info_ventas (idCliente, valorPagar, fechaVenta, estado, precio, descripcion) VALUES (?, ?, ?, ?, ?, ?)", 
            Statement.RETURN_GENERATED_KEYS
        );
        consulta.setInt(1, objeto.getIdCliente());
        consulta.setDouble(2, objeto.getValorPagar());
        consulta.setString(3, objeto.getFechaVenta());
        consulta.setInt(4, objeto.getEstado());
        consulta.setDouble(5, objeto.getPrecio());
        consulta.setString(6, objeto.getDescripcion() != null ? objeto.getDescripcion() : "Sin descripción");

        if (consulta.executeUpdate() > 0) {
            respuesta = true;
        }
        ResultSet rs = consulta.getGeneratedKeys();
        if (rs.next()) {
            iDColVar = rs.getBigDecimal(1);
            idInfoRegistrada = iDColVar.intValue();
        }
        rs.close();
        consulta.close();
        conexion.close();
    } catch (SQLException e) {
        System.out.println("Error al guardar la informacion de venta: " + e);
    }
    return respuesta;
}
    
 
    //metodo para guardar el detalle de venta
     
    public boolean guardarDetalle(DetallesDeVenta objeto) {
        boolean respuesta = false;
        Connection conexion = Conexion.conectar();
        try {
            PreparedStatement consulta = conexion.prepareStatement(
            "INSERT INTO tabla_detalles_venta (idVenta, idProducto, cantidad, precioUnitario, subTotal, descuento, totalPagar, estado) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            consulta.setInt(1, idInfoRegistrada);              
            consulta.setInt(2, objeto.getIdProducto());        
            consulta.setInt(3, objeto.getCantidad());          
            consulta.setDouble(4, objeto.getPrecioUnitario()); 
            consulta.setDouble(5, objeto.getSubTotal());       
            consulta.setDouble(6, objeto.getDescuento());      
            consulta.setDouble(7, objeto.getTotalPagar());     
            consulta.setInt(8, objeto.getEstado());

            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error al guardar detalle de venta: " + e);
        }
        return respuesta;
    }
    
    // metodo para actualizar info venta
    public boolean actualizar(InformacionVenta objeto, int idinfoVenta) {
        boolean respuesta = false;
        Connection conexion = Conexion.conectar();
        try {

            PreparedStatement consulta = conexion.prepareStatement(
                    "update tabla_info_ventas set idCliente = ?, estado = ? "
                            + "where idVenta ='" + idinfoVenta + "'");
            consulta.setInt(1, objeto.getIdCliente());
            consulta.setInt(2, objeto.getEstado());
           
            if (consulta.executeUpdate() > 0) {
                respuesta = true;
            }
            conexion.close();
        } catch (SQLException e) {
            System.out.println("Error al actualizar la informacion de venta: " + e);
        }
        return respuesta;
    }
}
