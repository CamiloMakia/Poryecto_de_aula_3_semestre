package model;

/**
 * @author srmakia
 */
public class DetallesDeVenta {

    private int idDetallesVenta;
    private int idVenta;
    private int idProducto;
    private String nombre;
    private int cantidad;
    private double precioUnitario;
    private double subTotal;
    private double descuento;
    private double totalPagar;
    private int estado;

    public DetallesDeVenta() {
    }
    

    public DetallesDeVenta(int idDetallesVenta, int idVenta, int idProducto, String nombre, int cantidad, double precioUnitario, double subTotal, double descuento, double totalPagar, int estado) {
        this.idDetallesVenta = idDetallesVenta;
        this.idVenta = idVenta;
        this.idProducto = idProducto;
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
        this.subTotal = subTotal;
        this.descuento = descuento;
        this.totalPagar = totalPagar;
        this.estado = estado;
    }
    
    public int getIdDetalleVenta() {
        return idDetallesVenta;
    }

    public void setIdDetalleVenta(int idDetalleVenta) {
        this.idDetallesVenta = idDetalleVenta;
    }

    public int getIdCabeceraVenta() {
        return idVenta;
    }

    public void setIdCabeceraVenta(int idCabeceraVenta) {
        this.idVenta = idCabeceraVenta;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    public double getSubTotal() {
        return subTotal;
    }

    public void setSubTotal(double subTotal) {
        this.subTotal = subTotal;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }

    public double getTotalPagar() {
        return totalPagar;
    }

    public void setTotalPagar(double totalPagar) {
        this.totalPagar = totalPagar;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }
    
    @Override
    public String toString() {
        return "DetalleVenta{" + "idDetalleVenta=" + idDetallesVenta + ", idCabeceraVenta=" + idVenta + ", idProducto=" + idProducto + ", nombre=" + nombre + ", cantidad=" + cantidad + ", precioUnitario=" + precioUnitario + ", subTotal=" + subTotal + ", descuento=" + descuento + ", totalPagar=" + totalPagar + ", estado=" + estado + '}';
    }
    

}
