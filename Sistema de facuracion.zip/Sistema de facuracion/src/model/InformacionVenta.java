package model;

/**
 * @author srmakia
 */
public class InformacionVenta {
    
    private int idVenta;
    private int idCliente;
    private double valorPagar;
    private String fechaVenta;
    private int estado;
    private int precio;
    private String descripcion = "";
    
    public InformacionVenta(){
    }
    
    public InformacionVenta(int idCabeceraventa, int idCliente, double valorPagar, String fechaVenta, int estado, int precio, String descripcion) {
        this.idVenta = idCabeceraventa;
        this.idCliente = idCliente;
        this.valorPagar = valorPagar;
        this.fechaVenta = fechaVenta;
        this.estado = estado;
        this.precio = precio;
        this.descripcion = descripcion;
    }

    public int getIdCabeceraventa() {
        return idVenta;
    }

    public void setIdCabeceraventa(int idCabeceraventa) {
        this.idVenta = idCabeceraventa;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public double getValorPagar() {
        return valorPagar;
    }

    public void setValorPagar(double valorPagar) {
        this.valorPagar = valorPagar;
    }

    public String getFechaVenta() {
        return fechaVenta;
    }

    public void setFechaVenta(String fechaVenta) {
        this.fechaVenta = fechaVenta;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return "InformacionVenta{" + "idVenta=" + idVenta + ", idCliente=" + idCliente + ", valorPagar=" + valorPagar + ", fechaVenta=" + fechaVenta + ", estado=" + estado + ", precio=" + precio + ", descripcion=" + descripcion + '}';
    }

    
   
    
    
    
}
