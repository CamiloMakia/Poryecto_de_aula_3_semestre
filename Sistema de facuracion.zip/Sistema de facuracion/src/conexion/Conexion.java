package conexion;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;

public class Conexion {

    //hacer la conexion a la base de datos
    public static Connection conectar() {

        try {

            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/db_sistema_ventas?useSSL=false", "srmakia", "srmakia");
            return connection;

        } catch (SQLException e) {
            System.out.println("Error en la conexion: " + e);
        }
        return null;

    }
}
